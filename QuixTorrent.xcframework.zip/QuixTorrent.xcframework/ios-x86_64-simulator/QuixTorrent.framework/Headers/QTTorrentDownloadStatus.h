#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, QTTorrentDownloadStatus) {
    QTTorrentDownloadStatusDownloading = 0,
    QTTorrentDownloadStatusFailed = 1,
    QTTorrentDownloadStatusFinished = 2,
    QTTorrentDownloadStatusPaused = 3,
    QTTorrentDownloadStatusProcessing = 4
};
