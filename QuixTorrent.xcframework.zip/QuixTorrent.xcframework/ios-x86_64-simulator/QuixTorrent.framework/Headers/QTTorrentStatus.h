typedef struct {
    float totalProgress;
    
    int downloadSpeed;
    int uploadSpeed;
    
    int peers;
    int seeds;
} QTTorrentStatus;
