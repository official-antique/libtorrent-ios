//
//  QuixTorrent.h
//  QuixTorrent
//
//  Created by Antique on 26/6/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for QuixTorrent.
FOUNDATION_EXPORT double QuixTorrentVersionNumber;

//! Project version string for QuixTorrent.
FOUNDATION_EXPORT const unsigned char QuixTorrentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuixTorrent/PublicHeader.h>
#import <QuixTorrent/QTSize.h>
#import <QuixTorrent/QTTorrentDownload.h>
#import <QuixTorrent/QTTorrentDownloadManager.h>
#import <QuixTorrent/QTTorrentDownloadManagerListener.h>
#import <QuixTorrent/QTTorrentDownloadStatus.h>
#import <QuixTorrent/QTTorrentStatus.h>
#import <QuixTorrent/QTTorrentStreamer.h>
