#import <Foundation/Foundation.h>

#import "QTTorrentStreamer.h"
#import "QTTorrentDownloadStatus.h"

@protocol QTTorrentDownloadManagerListener;

NS_ASSUME_NONNULL_BEGIN

@interface QTTorrentDownload : QTTorrentStreamer
@property (nonatomic, nullable, weak) id<QTTorrentDownloadManagerListener> delegate;
@property (nonatomic, readonly) QTTorrentDownloadStatus downloadStatus;
@property (strong, nonatomic) NSDictionary<NSString *, id> *metadata;


+(NSURL * _Nullable) downloadDirectoryURL;


-(instancetype) initWithMetadata:(NSDictionary<NSString *, id> *)metadata downloadStatus:(QTTorrentDownloadStatus)downloadStatus NS_DESIGNATED_INITIALIZER;
-(instancetype _Nullable) initWithPropertyList:(NSString *)propertyList;


-(void) pause;
-(void) resume;
-(void) stop;


-(BOOL) delete;
-(BOOL) save;


-(void) startDownloadingFromMagnetLink:(NSString *)magnetLink;

#pragma mark - Hidden methods
+(instancetype) __unavailable sharedStreamer;
+(instancetype) __unavailable new;
-(instancetype) __unavailable init;
-(void) __unavailable startStreamingFromMagnetLink:(NSString *)magnetLink progress:(QTTorrentStreamerProgress _Nullable)progress failure:(QTTorrentStreamerFailure _Nullable)failure;
@end

NS_ASSUME_NONNULL_END
