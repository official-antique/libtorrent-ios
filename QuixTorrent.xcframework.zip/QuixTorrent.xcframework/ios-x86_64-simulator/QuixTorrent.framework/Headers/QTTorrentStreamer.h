#import <Foundation/Foundation.h>

#import "QTTorrentStatus.h"

@class QTSize;

typedef void (^QTTorrentStreamerProgress)(QTTorrentStatus status);
typedef void (^QTTorrentStreamerFailure)(NSError * _Nonnull error);

NS_ASSUME_NONNULL_BEGIN

@interface QTTorrentStreamer : NSObject
@property (nonatomic, nullable, readonly, strong) NSString *fileName;
@property (nonatomic, readonly, strong) QTSize *fileSize;

@property (nonatomic, nullable, readonly, strong) NSString *savePath;

@property (nonatomic, readonly) QTTorrentStatus torrentStatus;
@property (nonatomic, readonly, strong) QTSize *totalDownloaded;


+(instancetype) shared;


-(void) cancelStreamingAndDeleteData:(BOOL)deleteData;
-(void) startStreamingFromMagnetLink:(NSString *)magnetLink progress:(QTTorrentStreamerProgress _Nullable)progress failure:(QTTorrentStreamerFailure _Nullable)failure;
@end

NS_ASSUME_NONNULL_END
