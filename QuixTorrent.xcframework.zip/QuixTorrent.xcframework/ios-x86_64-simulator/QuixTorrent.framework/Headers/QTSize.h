#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface QTSize : NSObject
+(instancetype) sizeWithLongLong:(long long)longLong;


-(instancetype) initWithLongLong:(long long)longLong NS_DESIGNATED_INITIALIZER;


@property (nonatomic, readonly) long long longLong;
@property (nonatomic, readonly, strong) NSString *string;


-(NSComparisonResult)compare:(QTSize *)size;


#pragma mark - Hidden methods
+(instancetype) __unavailable new;
-(instancetype) __unavailable init;
@end

NS_ASSUME_NONNULL_END
