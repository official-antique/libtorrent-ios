#import <Foundation/Foundation.h>

#import "QTTorrentDownloadStatus.h"
#import "QTTorrentStatus.h"

@class QTTorrentDownload;

NS_ASSUME_NONNULL_BEGIN

@protocol QTTorrentDownloadManagerListener <NSObject>
@optional
-(void) downloadDidFail:(QTTorrentDownload *)download withError:(NSError *)error;
-(void) downloadStatusDidChange:(QTTorrentDownloadStatus)downloadStatus forDownload:(QTTorrentDownload *)download;
-(void) torrentStatusDidChange:(QTTorrentStatus)torrentStatus forDownload:(QTTorrentDownload *)download;
@end

NS_ASSUME_NONNULL_END
