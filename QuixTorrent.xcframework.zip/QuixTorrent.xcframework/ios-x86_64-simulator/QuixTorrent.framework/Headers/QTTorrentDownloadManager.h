#import <Foundation/Foundation.h>

#import "QTTorrentStreamer.h"

@class QTTorrentDownload;
@protocol QTTorrentDownloadManagerListener;

NS_ASSUME_NONNULL_BEGIN

@interface QTTorrentDownloadManager : NSObject
@property (strong, nonatomic, readonly) NSArray<QTTorrentDownload *> *active;
@property (strong, nonatomic, readonly) NSArray<QTTorrentDownload *> *completed;


+(instancetype) shared;


-(void) add:(id<QTTorrentDownloadManagerListener>)listener;
-(void) remove:(id<QTTorrentDownloadManagerListener>)listener;


-(QTTorrentDownload *) startDownloadingFromMagnetLink:(NSString *)magnetLink metadata:(NSDictionary<NSString *, id> *)metadata;


-(void) pause:(QTTorrentDownload *)download;
-(void) resume:(QTTorrentDownload *)download;
-(void) stop:(QTTorrentDownload *)download;


-(BOOL) delete:(QTTorrentDownload *)download;
-(BOOL) save:(QTTorrentDownload *)download;
@end

NS_ASSUME_NONNULL_END


