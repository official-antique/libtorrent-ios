#import <libtorrent/add_torrent_params.hpp>
#import <libtorrent/magnet_uri.hpp>
#import <libtorrent/read_resume_data.hpp>
#import <libtorrent/session.hpp>
#import <libtorrent/torrent_info.hpp>
#import <libtorrent/write_resume_data.hpp>

#import "QTTorrentStreamer.h"

@interface QTTorrentStreamer () {
    @protected
    libtorrent::session *_session;
    
    QTTorrentStatus _torrentStatus;
    
    NSString *_fileName;
    NSString *_savePath;
    
    long long _requiredSpace;
    long long _totalDownloaded;
}

@property (nonatomic, nullable, strong) dispatch_queue_t alertsQueue;
@property (getter=isAlertsLoopActive, nonatomic) BOOL alertsLoopActive;
@property (getter=isFinished, nonatomic) BOOL finished;

@property (copy, nonatomic, nullable) QTTorrentStreamerProgress progressBlock;
@property (copy, nonatomic, nullable) QTTorrentStreamerFailure failureBlock;

@property (nonatomic) libtorrent::torrent_status status;

-(void) startStreamingFromMagnetLink:(NSString * _Nonnull)filePathOrMagnetLink directoryName:(NSString * _Nullable)directoryName progress:(QTTorrentStreamerProgress _Nullable)progress failure:(QTTorrentStreamerFailure _Nullable)failure;
@end
